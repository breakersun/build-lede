module("luci.controller.ddns",package.seeall)
local u=require"nixio"
local w=require"nixio.fs"
local s=require"luci.dispatcher"
local t=require"luci.http"
local e=require"luci.i18n"
local i=require"luci.model.ipkg"
local m=require"luci.sys"
local c=require"luci.model.uci"
local f=require"luci.util"
local a=require"luci.tools.ddns"
luci_helper="/usr/lib/ddns/dynamic_dns_lucihelper.sh"
local o="ddns-scripts"
local n="2.7.7"
local l=luci_helper..[[ -V | awk {'print $2'}]]
local r="luci-app-ddns"
local h="Dynamic DNS"
local d="2.4.9-1"
function index()
local e=require"nixio.fs"
local t=require"luci.sys"
local t=require"luci.tools.ddns"
local t=require"luci.model.uci"
if not e.access("/etc/config/ddns")then
e.writefile("/etc/config/ddns","")
end
local t=t.cursor()
local a=false
t:foreach("ddns","service",function(e)
if not e["lookup_host"]and e["domain"]then
t:set("ddns",e[".name"],"lookup_host",e["domain"])
a=true
end
end)
if a then t:commit("ddns")end
t:unload("ddns")
entry({"admin","services","ddns"},cbi("ddns/overview"),_("Dynamic DNS"),59)
entry({"admin","services","ddns","detail"},cbi("ddns/detail"),nil).leaf=true
entry({"admin","services","ddns","hints"},cbi("ddns/hints",
{hideapplybtn=true,hidesavebtn=true,hideresetbtn=true}),nil).leaf=true
entry({"admin","services","ddns","global"},cbi("ddns/global"),nil).leaf=true
entry({"admin","services","ddns","logview"},call("logread")).leaf=true
entry({"admin","services","ddns","startstop"},post("startstop")).leaf=true
entry({"admin","services","ddns","status"},call("status")).leaf=true
end
function app_description()
return e.translate("Dynamic DNS allows that your router can be reached with "..
"a fixed hostname while having a dynamically changing IP address.")
..[[<br />]]
..e.translate("OpenWrt Wiki")..": "
..[[<a href="http://wiki.openwrt.org/doc/howto/ddns.client" target="_blank">]]
..e.translate("DDNS Client Documentation")..[[</a>]]
.." --- "
..[[<a href="http://wiki.openwrt.org/doc/uci/ddns" target="_blank">]]
..e.translate("DDNS Client Configuration")..[[</a>]]
end
function app_title_back()
return[[<a href="]]
..s.build_url("admin","services","ddns")
..[[">]]
..e.translate(h)
..[[</a>]]
end
function app_title_main()
return[[<a href="javascript:alert(']]
..e.translate("Version Information")
..[[\n\n]]..r
..[[\n\t]]..e.translate("Version")..[[:\t]]..d
..[[\n\n]]..o..[[ ]]..e.translate("required")..[[:]]
..[[\n\t]]..e.translate("Version")..[[:\t]]
..n..[[ ]]..e.translate("or higher")
..[[\n\n]]..o..[[ ]]..e.translate("installed")..[[:]]
..[[\n\t]]..e.translate("Version")..[[:\t]]
..(service_version()or e.translate("NOT installed"))
..[[\n\n]]
..[[')">]]
..e.translate(h)
..[[</a>]]
end
function service_version()
local e=nil
e=f.exec(l)
if#e>0 then return e end
i.list_installed(o,function(a,t,a)
if t and(#t>0)then e=t end
end
)
return e
end
function service_ok()
return i.compare_versions((service_version()or"0"),">=",n)
end
local function d()
local c=c.cursor()
local e=m.init.enabled("ddns")and 1 or 0
local t=s.build_url("admin","system","startup")
local i={}
i[#i+1]={
enabled=e,
url_up=t,
}
c:foreach("ddns","service",function(e)
local n=e[".name"]
local d=tonumber(e["enabled"])or 0
local l="_empty_"
local o="_empty_"
local t=a.calc_seconds(
tonumber(e["force_interval"])or 72,
e["force_unit"]or"hours")
local r=a.get_pid(n)
local s=m.uptime()
local h=a.get_lastupd(n)
if h>s then
h=0
end
if h==0 then
l="_never_"
else
local e=os.time()-s+h
l=a.epoch2date(e)
o=a.epoch2date(e+t)
end
t=(t>s)and s or t
if r>0 and(h+t-s)<=0 then
o="_verify_"
elseif t==0 then
o="_runonce_"
elseif r==0 and d==0 then
o="_disabled_"
elseif r==0 and d~=0 then
o="_stopped_"
end
local s=e["interface"]or"wan"
local h=tonumber(e["use_ipv6"])or 0
local t=(h==1)and"IPv6"or"IPv4"
s=t.." / "..s
local u=e["lookup_host"]or"_nolookup_"
local t=a.calc_seconds(
tonumber(e["check_interval"])or 10,
e["check_unit"]or"minutes")
local t=a.get_regip(n,t)
if t=="NOFILE"then
local a=e["dns_server"]or""
local s=tonumber(e["force_ipversion"]or 0)
local o=tonumber(e["force_dnstcp"]or 0)
local i=tonumber(e["is_glue"]or 0)
local e=luci_helper..[[ -]]
if(h==1)then e=e..[[6]]end
if(s==1)then e=e..[[f]]end
if(o==1)then e=e..[[t]]end
if(i==1)then e=e..[[g]]end
e=e..[[l ]]..u
e=e..[[ -S ]]..n
if(#a>0)then e=e..[[ -d ]]..a end
e=e..[[ -- get_registered_ip]]
t=m.exec(e)
end
if t==""then
t="_nodata_"
end
i[#i+1]={
section=n,
enabled=d,
iface=s,
lookup=u,
reg_ip=t,
pid=r,
datelast=l,
datenext=o
}
end)
c:unload("ddns")
return i
end
function logread(o)
local a=c.cursor()
local e=a:get("ddns","global","ddns_logdir")or"/var/log/ddns"
local e=e.."/"..o..".log"
local e=w.readfile(e)
if not e or#e==0 then
e="_nodata_"
end
a:unload("ddns")
t.write(e)
end
function startstop(o,n)
local e=c.cursor()
local i=a.get_pid(o)
local a={}
if i>0 then
local e=u.kill(i,15)
u.nanosleep(2)
a=d()
t.prepare_content("application/json")
t.write_json(a)
return
end
local i=true
local s=e:changes("ddns")
for t,e in pairs(s)do
if t~="ddns"then
i=false
break
end
for t,e in pairs(e)do
if t~=o then
i=false
break
end
for e,t in pairs(e)do
if e~="enabled"then
i=false
break
end
end
end
end
if not i then
t.write("_uncommitted_")
return
end
e:set("ddns",o,"enabled",((n=="true")and"1"or"0"))
e:save("ddns")
e:commit("ddns")
e:unload("ddns")
local e="%s -S %s -- start"%{luci_helper,f.shellquote(o)}
os.execute(e)
u.nanosleep(3)
a=d()
t.prepare_content("application/json")
t.write_json(a)
end
function status()
local e=d()
t.prepare_content("application/json")
t.write_json(e)
end
