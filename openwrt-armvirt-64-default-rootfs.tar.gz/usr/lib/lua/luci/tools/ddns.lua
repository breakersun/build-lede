module("luci.tools.ddns",package.seeall)
local n=require"nixio"
local t=require"nixio.fs"
local e=require"luci.model.ipkg"
local a=require"luci.model.uci"
local e=require"luci.sys"
local o=require"luci.util"
local function o()
local a,e=t.glob("/etc/ssl/certs/*.crt")
if(e==0)then a,e=t.glob("/etc/ssl/certs/*.pem")end
return(e>0)
end
has_wgetssl=(e.call([[which wget-ssl >/dev/null 2>&1]])==0)
has_curl=(e.call([[which curl >/dev/null 2>&1]])==0)
has_curlssl=(e.call([[$(which curl) -V 2>&1 | grep "Protocols:" | grep -qF "https"]])~=0)
has_curlpxy=(e.call([[grep -i "all_proxy" /usr/lib/libcurl.so* >/dev/null 2>&1]])==0)
has_fetch=(e.call([[which uclient-fetch >/dev/null 2>&1]])==0)
has_fetchssl=t.access("/lib/libustream-ssl.so")
has_bbwget=(e.call([[$(which wget) -V 2>&1 | grep -iqF "busybox"]])==0)
has_bindhost=(e.call([[which host >/dev/null 2>&1]])==0)
or(e.call([[which khost >/dev/null 2>&1]])==0)
or(e.call([[which drill >/dev/null 2>&1]])==0)
has_hostip=(e.call([[which hostip >/dev/null 2>&1]])==0)
has_nslookup=(e.call([[$(which nslookup) localhost 2>&1 | grep -qF "(null)"]])~=0)
has_ipv6=(t.access("/proc/net/ipv6_route")and t.access("/usr/sbin/ip6tables"))
has_ssl=(has_wgetssl or has_curlssl or(has_fetch and has_fetchssl))
has_proxy=(has_wgetssl or has_curlpxy or has_fetch or has_bbwget)
has_forceip=(has_wgetssl or has_curl or has_fetch)
has_dnsserver=(has_bindhost or has_hostip or has_nslookup)
has_bindnet=(has_wgetssl or has_curl)
has_cacerts=o()
function calc_seconds(e,t)
if not tonumber(e)then
return nil
elseif t=="days"then
return(tonumber(e)*86400)
elseif t=="hours"then
return(tonumber(e)*3600)
elseif t=="minutes"then
return(tonumber(e)*60)
elseif t=="seconds"then
return tonumber(e)
else
return nil
end
end
function epoch2date(o,e)
if not e or#e<2 then
local t=a.cursor()
e=t:get("ddns","global","ddns_dateformat")or"%F %R"
t:unload("ddns")
end
e=e:gsub("%%n","<br />")
e=e:gsub("%%t","    ")
return os.date(e,o)
end
function get_lastupd(o)
local e=a.cursor()
local a=e:get("ddns","global","ddns_rundir")or"/var/run/ddns"
local t=tonumber(t.readfile("%s/%s.update"%{a,o})or 0)
e:unload("ddns")
return t
end
function get_regip(e,n)
local o=a.cursor()
local a=o:get("ddns","global","ddns_rundir")or"/var/run/ddns"
local i="NOFILE"
if t.access("%s/%s.ip"%{a,e})then
local o=t.stat("%s/%s.ip"%{a,e},"ctime")or 0
local s=os.time()
if s<(o+n+9)then
i=t.readfile("%s/%s.ip"%{a,e})
end
end
o:unload("ddns")
return i
end
function get_pid(e)
local a=a.cursor()
local o=a:get("ddns","global","ddns_rundir")or"/var/run/ddns"
local e=tonumber(t.readfile("%s/%s.pid"%{o,e})or 0)
if e>0 and not n.kill(e,0)then
e=0
end
a:unload("ddns")
return e
end
function read_value(t,a,o)
local e
if t.tag_error[a]then
e=t:formvalue(a)
else
e=t.map:get(a,o)
end
if not e then
return nil
elseif not t.cast or t.cast==type(e)then
return e
elseif t.cast=="string"then
if type(e)=="table"then
return e[1]
end
elseif t.cast=="table"then
return{e}
end
end
function value_parse(e,i,d)
local t=e:formvalue(i)
local r=(t and(#t>0))
local n=e:cfgvalue(i)
local h=(e.rmempty or e.optional)
local o
if type(t)=="table"and type(n)=="table"then
o=(#t==#n)
if o then
for e=1,#t do
if n[e]~=t[e]then
o=false
end
end
end
if o then
t=n
end
end
local a,s=e:validate(t)
if not a then
if d then
return
end
if r then
e:add_error(i,"invalid",s or e.title..": invalid")
return
elseif not h then
e:add_error(i,"missing",s or e.title..": missing")
return
elseif s then
e:add_error(i,"invalid",s)
return
end
end
o=(a==n)
local l=(a and(#a>0))and true or false
local d=(a==e.default)
if h and(not l or d)then
if e:remove(i)then
e.section.changed=true
end
return
end
if not e.forcewrite and o then
return
end
assert(a,"\n option: "..e.option..
"\n fvalue: "..tostring(t)..
"\n fexist: "..tostring(r)..
"\n cvalue: "..tostring(n)..
"\n vvalue: "..tostring(a)..
"\n vexist: "..tostring(l)..
"\n rm_opt: "..tostring(h)..
"\n eq_cfg: "..tostring(o)..
"\n eq_def: "..tostring(d)..
"\n errtxt: "..tostring(s))
if e:write(i,a)and not o then
e.section.changed=true
end
end
function parse_url(t)
local e={}
t=string.gsub(t,"#(.*)$",
function(t)
e.fragment=t
return""
end)
t=string.gsub(t,"^([%w][%w%+%-%.]*)%:",
function(t)
e.scheme=string.lower(t);
return""
end)
t=string.gsub(t,"^//([^/]*)",
function(t)
e.authority=t
return""
end)
t=string.gsub(t,"%?(.*)",
function(t)
e.query=t
return""
end)
t=string.gsub(t,"%;(.*)",
function(t)
e.params=t
return""
end)
e.path=t
local t=e.authority
if not t then
return e
end
t=string.gsub(t,"^([^@]*)@",
function(t)
e.userinfo=t;
return""
end)
t=string.gsub(t,":([0-9]*)$",
function(t)
if t~=""then
e.port=t
end;
return""
end)
if t~=""then
e.host=t
end
local t=e.userinfo
if not t then
return e
end
t=string.gsub(t,":([^:]*)$",
function(t)
e.password=t;
return""
end)
e.user=t
return e
end
