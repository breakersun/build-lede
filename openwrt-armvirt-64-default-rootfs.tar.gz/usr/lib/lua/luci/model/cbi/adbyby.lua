local a=require"nixio.fs"
local i=require"luci.sys"
local u=require"luci.http"
local h=require"luci.dispatcher"
local d=i.exec("head -1 /usr/share/adbyby/data/lazy.txt | awk -F' ' '{print $3,$4}'")
local r=i.exec("head -1 /usr/share/adbyby/data/video.txt | awk -F' ' '{print $3,$4}'")
local n=i.exec("grep -v '^!' /usr/share/adbyby/data/rules.txt | wc -l")
local n=i.exec("cat /usr/share/adbyby/data/user.txt | wc -l")
local n=i.exec("cat /tmp/adbyby.updated 2>/dev/null")
local l=i.exec("cat /usr/share/adbyby/dnsmasq.adblock | wc -l")
m=Map("adbyby")
m.title=translate("Adbyby Plus +")
m.description=translate("Adbyby Plus + can filter all kinds of banners, popups, video ads, and prevent tracking, privacy theft and a variety of malicious websites<br /><font color=\"red\">Plus + version combination mode can operation with Adblock Plus Host，filtering ads without losing bandwidth</font>")
m:section(SimpleSection).template="adbyby/adbyby_status"
s=m:section(TypedSection,"adbyby")
s.anonymous=true
s:tab("basic",translate("Base Setting"))
o=s:taboption("basic",Flag,"enable")
o.title=translate("Enable")
o.default=0
o.rmempty=false
o=s:taboption("basic",ListValue,"wan_mode")
o.title=translate("Running Mode")
o:value("0",translate("Global Mode（The slowest, the best effects）"))
o:value("1",translate("Plus + Mode（Filter domain name list and blacklist website.Recommended）"))
o:value("2",translate("No filter Mode (Must set in Client Filter Mode Settings manually)"))
o.default=1
o.rmempty=false
mem=s:taboption("basic",Flag,"mem_mode")
mem.title=translate("RAM Running Mode")
mem.default=1
mem.rmempty=false
mem.description=translate("Running Adbyby in RAM.More speed,less disk consumption")
o=s:taboption("basic",Button,"restart")
o.title=translate("Adbyby and Rule state")
o.inputtitle=translate("Restart Adbyby")
o.description=string.format("<strong>Last Update Checked：</strong> %s<br /><strong>Lazy Rule：</strong>%s <br /><strong>Video Rule：</strong>%s",n,d,r)
o.inputstyle="reload"
o.write=function()
i.call("nohup sh /usr/share/adbyby/adupdate.sh > /tmp/adupdate.log 2>&1 &")
i.call("sleep 4")
u.redirect(h.build_url("admin","services","adbyby"))
end
s:tab("advanced",translate("Advance Setting"))
o=s:taboption("advanced",Flag,"cron_mode")
o.title=translate("Update the rule at 6 a.m. every morning and restart adbyby")
o.default=0
o.rmempty=false
o.description=translate(string.format("<strong><font color=blue>Adblock Plus Host List：</font></strong> %s Lines<br /><br />",l))
updatead=s:taboption("advanced",Button,"updatead",translate("Manually force update<br />Adblock Plus Host List"),translate("Note: It needs to download and convert the rules. The background process may takes 60-120 seconds to run. <br / > After completed it would automatically refresh, please do not duplicate click!"))
updatead.inputtitle=translate("Manually force update")
updatead.inputstyle="apply"
updatead.write=function()
i.call("nohup sh /usr/share/adbyby/adblock.sh > /tmp/adupdate.log 2>&1 &")
end
o=s:taboption("advanced",Flag,"block_ios")
o.title=translate("Block Apple iOS OTA update")
o.default=0
o.rmempty=false
s:tab("help",translate("Plus+ Domain List"))
local i="/usr/share/adbyby/adhost.conf"
o=s:taboption("help",TextValue,"conf")
o.description=translate("（!）Note that you should fill to the domain name ONLY. For example, http://www.baidu.com only needs to write to baidu.com. One line for each")
o.rows=13
o.wrap="off"
o.cfgvalue=function(e,e)
return a.readfile(i)or""
end
o.write=function(t,t,e)
a.writefile(i,e:gsub("\r\n","\n"))
end
s:tab("esc",translate("Bypass Domain List"))
local i="/usr/share/adbyby/adesc.conf"
o=s:taboption("esc",TextValue,"escconf")
o.description=translate("（!）Will Never filter these Domain")
o.rows=13
o.wrap="off"
o.cfgvalue=function(e,e)
return a.readfile(i)or""
end
o.write=function(t,t,e)
a.writefile(i,e:gsub("\r\n","\n"))
end
s:tab("black",translate("Black Domain List"))
local i="/usr/share/adbyby/adblack.conf"
o=s:taboption("black",TextValue,"blackconf")
o.description=translate("（!）Will Always block these Domain")
o.rows=13
o.wrap="off"
o.cfgvalue=function(e,e)
return a.readfile(i)or""
end
o.write=function(t,t,e)
a.writefile(i,e:gsub("\r\n","\n"))
end
s:tab("block",translate("Black IP List"))
local i="/usr/share/adbyby/blockip.conf"
o=s:taboption("block",TextValue,"blockconf")
o.description=translate("（!）Will Always block these IP")
o.rows=13
o.wrap="off"
o.cfgvalue=function(e,e)
return a.readfile(i)or" "
end
o.write=function(t,t,e)
a.writefile(i,e:gsub("\r\n","\n"))
end
s:tab("user",translate("User-defined Rule"))
local i="/usr/share/adbyby/rules.txt"
o=s:taboption("user",TextValue,"rules")
o.description=translate("Each line of the beginning exclamation mark is considered an annotation.")
o.rows=13
o.wrap="off"
o.cfgvalue=function(e,e)
return a.readfile(i)or""
end
o.write=function(o,o,e)
a.writefile(i,e:gsub("\r\n","\n"))
end
t=m:section(TypedSection,"acl_rule",translate("<strong>Client Filter Mode Settings</strong>"),
translate("Filter mode settings can be set to specific LAN clients ( <font color=blue> No filter , Global filter </font> ) . Does not need to be set by default."))
t.template="cbi/tblsection"
t.sortable=true
t.anonymous=true
t.addremove=true
e=t:option(Value,"ipaddr",translate("IP Address"))
e.width="40%"
e.datatype="ip4addr"
e.placeholder="0.0.0.0/0"
luci.ip.neighbors({family=4},function(t)
if t.reachable then
e:value(t.dest:string())
end
end)
e=t:option(ListValue,"filter_mode",translate("Filter Mode"))
e.width="40%"
e.default="disable"
e.rmempty=false
e:value("disable",translate("No filter"))
e:value("global",translate("Global filter"))
return m
