local n=require"nixio.fs"
local t=require"luci.sys"
local h=require"luci.model.uci".cursor()
local o=require"luci.util"
local a=require"luci.i18n"
module("luci.model.cbi.v2ray_server.api.v2ray",package.seeall)
local u="https://api.github.com/repos/v2ray/v2ray-core/releases/latest"
local m="/usr/bin/wget"
local c={"--no-check-certificate","--quiet","--timeout=10","--tries=2"}
local l="/usr/bin/curl"
local d=40
local function r(t,e)
e=e or 1
if t[e]~=nil then
return t[e],r(t,e+1)
end
end
local function i(r,h,a,i)
local o=require"os"
local e=require"nixio"
local s,n=e.pipe()
local t=e.fork()
if t>0 then
n:close()
if a or i then
local n=o.time()
while true do
if i and o.difftime(o.time(),n)>=i then
e.kill(t,e.const.SIGTERM)
return 1
end
if a then
local e=s:read(2048)
if e and#e>0 then
a(e)
end
end
local n,t,o=e.waitpid(t,"nohang")
if n and t=="exited"then
return o
end
if not a and i then
e.nanosleep(1)
end
end
else
local a,e,t=e.waitpid(t)
return a and e=="exited"and t
end
elseif t==0 then
e.dup(n,e.stdout)
s:close()
n:close()
e.exece(r,h,nil)
e.stdout:close()
o.exit(1)
end
end
local function s(i,e,t)
local a=table
local i=o.split(i,"[%.%-]",nil,true)
local o=o.split(t,"[%.%-]",nil,true)
local t=a.getn(i)
local a=a.getn(o)
if(t<a)then
t=a
end
for t=1,t,1 do
local a=i[t]or""
local t=o[t]or""
if e=="~="and(a~=t)then return true end
if(e=="<"or e=="<=")and(a<t)then return true end
if(e==">"or e==">=")and(a>t)then return true end
if(a~=t)then return false end
end
return not(e=="<"or e==">")
end
local function y()
local e=nixio.uname().machine or""
if e=="mips"then
if n.access("/usr/lib/os-release")then
e=t.exec("grep 'LEDE_BOARD' /usr/lib/os-release | grep -oE 'ramips|ar71xx'")
elseif n.access("/etc/openwrt_release")then
e=t.exec("grep 'DISTRIB_TARGET' /etc/openwrt_release | grep -oE 'ramips|ar71xx'")
end
end
return o.trim(e)
end
local function f(e)
local t=""
local a=""
if e=="x86_64"then
t="64"
elseif e=="ramips"then
t="mipsle"
elseif e=="ar71xx"then
t="mips"
elseif e:match("^i[%d]86$")then
t="32"
elseif e:match("^armv[5-8]")then
t="arm"
a=e:match("[5-8]")
end
return t,a
end
local function w(e)
local t=require"luci.jsonc"
local a={}
local e=luci.sys.exec(l.." -sL "..e)
if e==""then
return{}
end
return t.parse(e)or{}
end
function get_config_option(t,e)
return h:get("v2ray","general",t)or e
end
function get_current_log_file(t)
local e=get_config_option("log_folder","/var/log/v2ray")
return"%s/%s.%s.log"%{e,t,"general"}
end
function is_running(e)
if e and e~=""then
local e=e:match(".*/([^/]+)$")or""
if e~=""then
return t.call("pidof %s >/dev/null"%e)==0
end
end
return false
end
function get_v2ray_version()
return luci.sys.exec("/usr/bin/v2ray/v2ray -version | awk '{print $2}' | sed -n 1P")
end
function to_check(e)
if not e or e==""then
e=y()
end
local t,h=f(e)
if t==""then
return{
code=1,
error=a.translate("Can't determine ARCH, or ARCH not supported. Please select manually.")
}
end
local e=w(u)
if e.tag_name==nil then
return{
code=1,
error=a.translate("Get remote version info failed.")
}
end
local o=e.tag_name:match("[^v]+")
local i=s(get_v2ray_version(),"<",o)
local n,s
if i then
n=e.html_url
for a,e in ipairs(e.assets)do
if e.name and e.name:match("linux%-"..t)then
s=e.browser_download_url
break
end
end
end
if i and not s then
return{
code=1,
version=o,
html_url=n,
type=t..h,
error=a.translate("New version found, but failed to get new version download url.")
}
end
return{
code=0,
update=i,
version=o,
url={
html=n,
download=s
},
type=t..h
}
end
function to_download(e)
if not e or e==""then
return{
code=1,
error=a.translate("Download url is required.")
}
end
t.call("/bin/rm -f /tmp/v2ray_download.*")
local t=o.trim(o.exec("mktemp -u -t v2ray_download.XXXXXX"))
local o=i(m,{
"-O",t,e,r(c)},nil,d)==0
if not o then
i("/bin/rm",{"-f",t})
return{
code=1,
error=a.translatef("File download failed or timed out: %s",e)
}
end
return{
code=0,
file=t
}
end
function to_extract(e,s)
local s=t.call("opkg list-installed | grep unzip > /dev/null")==0
if not s then
t.call("opkg update && opkg install unzip > /dev/null")
end
if not e or e==""or not n.access(e)then
return{
code=1,
error=a.translate("File path required.")
}
end
t.call("/bin/rm -rf /tmp/v2ray_extract.*")
local a=o.trim(o.exec("mktemp -d -t v2ray_extract.XXXXXX"))
local t={}
i("/usr/bin/unzip",{"-o",e,"-d",a},
function(e)t[#t+1]=e end)
local t=o.split(table.concat(t))
i("/bin/rm",{"-f",e})
return{
code=0,
file=a
}
end
function to_move(o)
if not o or o==""then
t.call("/bin/rm -rf /tmp/v2ray_extract.*")
return{
code=1,
error=a.translate("Client file is required.")
}
end
local e="/usr/bin/v2ray"
t.call("mkdir -p "..e)
local o=i("/bin/mv",{"-f",o.."/v2ray",o.."/v2ctl",e},nil,d)==0
if not o or not n.access(e)then
t.call("/bin/rm -rf /tmp/v2ray_extract.*")
return{
code=1,
error=a.translatef("Can't move new file to path: %s",e)
}
end
i("/bin/chmod",{"-R","755",e})
t.call("/bin/rm -rf /tmp/v2ray_extract.*")
return{code=0}
end
