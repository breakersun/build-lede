#!/bin/sh

sleep 40 && /etc/init.d/adbyby restart
